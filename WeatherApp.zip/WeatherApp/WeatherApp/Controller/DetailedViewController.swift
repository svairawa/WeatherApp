//
//  DetailedViewController.swift
//  WeatherApp
//
//  Created by Shanya Vairawanathan on 26/5/20.
//  Copyright © 2020 James Farrey. All rights reserved.
//

import UIKit

class DetailedViewController: UIViewController {
    
    var weather_arr = Array<Data> ()

    @IBOutlet weak var subName: UILabel!
    
    @IBOutlet weak var weatherCond: UILabel!
    
    @IBOutlet weak var temperature: UILabel!
    
    @IBOutlet weak var feelsLike: UILabel!
    
    @IBOutlet weak var humidity: UILabel!
    
    @IBOutlet weak var wind: UILabel!
    
    @IBOutlet weak var lastUpdated: UILabel!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("Weather array: \(weather_arr)")
        
        for item in weather_arr {
            let date = NSDate(timeIntervalSince1970: item.weatherLastUpdated ?? 0)
            self.subName.text = item.name
            self.weatherCond.text = item.weatherCondition
            self.temperature.text = "\(item.weatherTemp ?? "?")°"
            self.feelsLike.text = item.weatherFeelsLike
            self.humidity.text = item.weatherHumidity
            self.wind.text = item.weatherWind
            self.lastUpdated.text = "Last Updated:\(date)"
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
