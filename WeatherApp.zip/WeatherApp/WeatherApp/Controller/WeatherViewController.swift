//
//  ViewController.swift
//  WeatherApp
//
//  Created by Shanya Vairawanathan on 25/5/20.
//  Copyright © 2020 James Farrey. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class WeatherViewController: UIViewController {
 
    let weather_url = "http://dnu5embx6omws.cloudfront.net/venues/weather.json"
    
    var weatherDetails = Array<Data>()
    var country_name:String? 
    var isFiltered: Bool? = false
    var selectedCountry:String?
    var filtered: [String?] = []

    @IBOutlet weak var tableView: UITableView!

    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    var refreshControl = UIRefreshControl()
    
    @IBOutlet weak var filterBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        getApiData()
        tableView.delegate = self
        tableView.dataSource = self
        self.isCountryFiltered()

        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh(_:)), for: .valueChanged)
        
    }
    
    func getApiData(){
        Alamofire.request(weather_url).responseJSON { (response) in
            print("Response value \(response)")
            do{
                if(response.result.isSuccess){
                    let result: WeatherDataModel = try JSONDecoder().decode(WeatherDataModel.self, from: response.data!)
                    self.weatherDetails = result.data ?? []

                    self.tableView.reloadData()
                }
                
            }catch{
                print("Error is: \(error)")
                
            }
        }
    }
    
    @objc func refresh(_ sender: AnyObject) {
        tableView.reloadData()
        refreshControl.endRefreshing()
    }
    
    @IBAction func filterBtnAction(_ sender: Any) {
        let cvc = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "CountriesViewController") as? CountriesViewController
        if(weatherDetails.count > 0){
            do{
                cvc?.country_arr = weatherDetails
            }catch{
                print("Error is: \(error)")
            }
        }
        self.navigationController!.pushViewController(cvc!, animated: true)
    }
    
    func isCountryFiltered(){
        if(isFiltered == true){
            weatherDetails = weatherDetails.filter{ $0.country?.countryName == selectedCountry }
            print("Weather deets:\(weatherDetails)")
            self.tableView.reloadData()
        }
        else {
            self.tableView.reloadData()
        }
    }
    
    @IBAction func selectionChange(_ sender: Any) {
        switch segmentedControl.selectedSegmentIndex
        {
        case 0:
            sortAlpha()
        case 1:
            sortTemp()
        case 2:
            sortLastUpdated()
        default:
            break
        }
    }
    
    func sortAlpha(){
        weatherDetails.sort(by: { $0.name! < $1.name! })
        self.tableView.reloadData()
    }
    
    func sortTemp(){
        weatherDetails.sort(by: { $0.weatherTemp ?? "N/R" < $1.weatherTemp ?? "N/R"})
        self.tableView.reloadData()
    }
    
    func sortLastUpdated(){
        weatherDetails.sort(by: { $0.weatherLastUpdated ?? 0 > $1.weatherLastUpdated ?? 0 })
        self.tableView.reloadData()
    }

}

extension WeatherViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return weatherDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MainTableViewCell") as! MainTableViewCell
        if(weatherDetails.count > 0){
            do{
                let weatherData = weatherDetails[indexPath.row]
                cell.sName.text = weatherData.name
                cell.weatherCond.text = weatherData.weatherCondition ?? "Not recorded"
                cell.temp.text = "\(weatherData.weatherTemp  ?? "N/R")°"
            }catch{
                print("Error is:\(error)")
            }
            
        }
        return cell
        
    }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        let vc = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "DetailedViewController") as? DetailedViewController
        if(weatherDetails.count > 0){
            do{
                let weatherData = weatherDetails[indexPath.row]
                vc?.weather_arr = [weatherData]
            }catch{
                print("Error is: \(error)")
            }
        }

        self.navigationController!.pushViewController(vc!, animated: true)
    }
}

extension WeatherViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}

