//
//  CountriesViewController.swift
//  WeatherApp
//
//  Created by Shanya Vairawanathan on 26/5/20.
//  Copyright © 2020 James Farrey. All rights reserved.
//

import UIKit

class CountriesViewController: UIViewController {

    @IBOutlet weak var countryTableView: UITableView!
    
    var country_arr = Array<Data> ()
    var onlyCountriesArr:[String?] = []
    var uniqueArray:[String?] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        countryTableView.delegate = self
        countryTableView.dataSource = self
        print("The country array is: \(country_arr)")
        for item in country_arr{
            for country in [item] {
                let countries = country.country?.countryName
                onlyCountriesArr.append(countries)
            }
        }
        uniqueArray = onlyCountriesArr.removingDuplicates()
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
extension Array where Element: Equatable {
    func removingDuplicates() -> Array {
        return reduce(into: []) { result, element in
            if !result.contains(element) {
                result.append(element)
            }
        }
    }
}

extension CountriesViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return uniqueArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "countryCell") as! countryCell
        if(uniqueArray.count > 0){
            do{
                cell.countryLbl.text = uniqueArray[indexPath.row]
            }catch{
                print("Error is:\(error)")
            }
            
        }
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        let vc = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "WeatherViewController") as? WeatherViewController
        if(uniqueArray.count > 0){
            do{
                vc?.country_name = uniqueArray[indexPath.row]
                vc?.isFiltered = true
            }catch{
                print("Error is: \(error)")
            }
        }
        dismiss(animated: true, completion: nil)
        self.navigationController!.pushViewController(vc!, animated: true)
    }
    
}


extension CountriesViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
}


class countryCell:UITableViewCell {
    
    @IBOutlet weak var countryLbl: UILabel!
    
}
