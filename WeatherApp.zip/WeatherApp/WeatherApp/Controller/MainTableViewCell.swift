//
//  TableViewCell.swift
//  WeatherApp
//
//  Created by Shanya Vairawanathan on 26/5/20.
//  Copyright © 2020 James Farrey. All rights reserved.
//

import UIKit

class MainTableViewCell: UITableViewCell {

    @IBOutlet weak var sName: UILabel!
    
    @IBOutlet weak var weatherCond: UILabel!
    
    @IBOutlet weak var temp: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
