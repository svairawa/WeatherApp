//
//  WeatherDataModel.swift
//  WeatherApp
//
//  Created by Shanya Vairawanathan on 25/5/20.
//  Copyright © 2020 James Farrey. All rights reserved.
//
import Foundation

struct Data: Codable {
    public var country : Country?
    public var name : String?
    public var sport : Sport?
    public var venueID : String?
    public var weatherCondition : String?
    public var weatherConditionIcon : String?
    public var weatherFeelsLike : String?
    public var weatherHumidity : String?
    public var weatherLastUpdated : Double?
    public var weatherTemp : String?
    public var weatherWind : String?

    
    enum CodingKeys: String, CodingKey {
        case venueID = "_venueID"
        case name = "_name"
        case country = "_country"
        case weatherCondition = "_weatherCondition"
        case weatherConditionIcon = "_weatherCondidtionIcon"
        case weatherWind = "_weatherWind"
        case weatherHumidity = "_weatherHumidity"
        case weatherTemp = "_weatherTemp"
        case weatherFeelsLike = "_weatherFeelsLike"
        case sport = "_sport"
        case weatherLastUpdated = "_weatherLastUpdated"

    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        venueID = try values.decodeIfPresent(String.self, forKey: .venueID)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        country = try values.decodeIfPresent(Country.self, forKey: .country)
        weatherCondition = try values.decodeIfPresent(String.self, forKey: .weatherCondition)
        weatherConditionIcon = try values.decodeIfPresent(String.self, forKey: .weatherConditionIcon)
        weatherWind = try values.decodeIfPresent(String.self, forKey: .weatherWind)
        weatherHumidity = try values.decodeIfPresent(String.self, forKey: .weatherHumidity)
        weatherTemp = try values.decodeIfPresent(String.self, forKey: .weatherTemp)
        weatherFeelsLike = try values.decodeIfPresent(String.self, forKey: .weatherFeelsLike)
        sport = try values.decodeIfPresent(Sport.self, forKey: .sport)
        weatherLastUpdated = try values.decodeIfPresent(Double.self, forKey: .weatherLastUpdated)
    }
    
}

struct WeatherDataModel: Codable {
    public var ret:Bool?
    public var isOkay:Bool?
    public var data:[Data]?
    
    enum CodingKeys: String, CodingKey {
        case ret = "ret"
        case isOkay = "isOkay"
        case data = "data"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        ret = try values.decodeIfPresent(Bool.self, forKey: .ret)
        isOkay = try values.decodeIfPresent(Bool.self, forKey: .isOkay)
        data = try values.decodeIfPresent([Data].self, forKey: .data)
    }
}

struct Country: Codable {
    public var countryID : String?
    public var countryName: String?
    
    enum CodingKeys: String, CodingKey {
        case countryID = "_countryID"
        case countryName = "_name"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        countryID = try values.decodeIfPresent(String.self, forKey: .countryID)
        countryName = try values.decodeIfPresent(String.self, forKey: .countryName)
    }
}

struct Sport: Codable {
    public var sportID: String?
    public var description: String?
    
    enum CodingKeys: String, CodingKey {
        case sportID = "_sportID"
        case description = "_description"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        sportID = try values.decodeIfPresent(String.self, forKey: .sportID)
        description = try values.decodeIfPresent(String.self, forKey: .description)
    }
    
}
